# Ayúdela a Yepeto  a cumplir con los requerimientos del reto 
# WORLD CRAFT ASCII: 
### Contexto
 
  


## Identificar el problema
### ¿Cuál es el problema/objetivo?

## Identificar los interesados
### ¿Quiénes son los interesados?

## Definir el problema
### ¿Qué información conozco (que nos dan)?

 
### ¿Qué información debo conocer (para lograr el objetivo)?
 
## Dividir el problema en subproblemas


## Estrategia
### Ejemplos particulares

 
### Estrategia de solución
1  
# Requisitos de software

## Algoritmo:  age
 
## ## Algoritmo:  CDIA

# Logros
Implementar los algoritmos en Python