'''
Parámetro CDIA tipo String
Retrona True o False
Función: Convierte a mayúsculas CDIA y listaCDIA y compara el parámetro de entrada CDIA contra la listaCDIA
'''
def CDIA_UNICO(CDIA):
  listaCDIA={"Luisfe@=g+","Lui?fe@=g+","Luikf&@=g+"}
  for n in listaCDIA:
    if n.upper() == CDIA.upper():
      return True
  return False
