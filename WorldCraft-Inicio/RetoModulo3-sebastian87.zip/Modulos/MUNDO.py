'''
Parámetros:
  edad_jugador:Entero
  jugador_nuevo:Boleano
  nivel_alcanzado:Entero
Retrona un número entero entre 1 y 6 que denota el nivel asignado según la función
Función: Compara los parámetros para que cumplan:
  Mundo 1: edad:>=12 & <=20 & jugador_nuevo:True
  Mundo 2: edad:>=12 & <=20 & jugador_nuevo:False
  Mundo 3: edad:>=12 & <=20 & jugador_nuevo:False & nivel_alzanzado:>=50
  Mundo 4: edad:>20 & jugador_nuevo:False
  Mundo 5: edad:>20 & jugador_nuevo:False & nivel_alcanzado:<50
  Mundo 6: edad:>20 & jugador_nuevo:Falseprint("Su mundo asignado es:", & nivel_alcanzado:>=50
'''
def ASIGNAR(edad_jugador, jugador_nuevo, nivel_alcanzado):
  #Mundo 1: edad:>=12 & <=20 & jugador_nuevo:True
  if (edad_jugador>=12 and edad_jugador<=20) and (jugador_nuevo==True):
    return 1
  #Mundo 2: edad:>=12 & <=20 & jugador_nuevo:False
  elif (edad_jugador>=12 and edad_jugador<=20) and (jugador_nuevo==False) and (nivel_alcanzado<50):
    return 2
  #Mundo 3: edad:>=12 & <=20 & jugador_nuevo:False & nivel_alzanzado:>=50
  elif (edad_jugador>=12 and edad_jugador<=20) and (jugador_nuevo==False) and (nivel_alcanzado>=50):
    return 3
  #Mundo 4: edad:>20 & jugador_nuevo:False
  elif (edad_jugador>20) and (jugador_nuevo==True):
    return 4
  #Mundo 5: edad:>20 & jugador_nuevo:False & nivel_alcanzado:<50
  elif (edad_jugador>20) and (jugador_nuevo==False) and (nivel_alcanzado<50):
    return 5
  #Mundo 6: edad:>20 & jugador_nuevo:Falseprint("Su mundo asignado es:", & nivel_alcanzado:>=50
  elif (edad_jugador>20)  and (jugador_nuevo==False) and (nivel_alcanzado>=50):
    return 6
