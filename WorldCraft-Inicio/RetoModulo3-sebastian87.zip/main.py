import Modulos.CDIA_UNICO as cdiaunico
import Modulos.age as edad
import Modulos.CDIA_VALIDAR as cdia_validar
import Modulos.MUNDO as mundo
from datetime import datetime


CDIA = ""
CDIA_EXISTE = ""
edad_jugador = 0
fecha_nacimiento = ""
edad_jugador = 0
jugador_nuevo = False
alias_usuario = ""
nivel_alcanzado = ""



def validarFormato(CDIA):
  if cdia_validar.validarCadena(CDIA):
    return True
#CDIA="Luisfe@=g+"
CDIA="Lukkke@=g+"

#"Luisfe@=g+"
#CDIA = input("Escriba su CDIA: ")
    
#Verificar formato de CDIA
if not validarFormato(CDIA):
  print("CDIA inválido")
else:
  print("CDIA válido")
  #Si cumple: Verficar existencia de CDIA
  if cdiaunico.CDIA_UNICO(CDIA):
    CDIA_EXISTE="existe"
    #Si no existe: Preguntar fecha de nacimiento
  else:
    CDIA_EXISTE="no existe"
    #Pedir fecha de nacimiento
    #date_time_str = input("Fecha de nacimiento [dd/mm/aaaa]: ")
    
    date_time_str = '18/04/2004'
    
    #Debe ser convertida a tipo Date eliminando el símbolo /
    fecha_nacimiento = datetime.strptime(date_time_str, '%d/%m/%Y')
    edad_jugador = edad.calculateAge(fecha_nacimiento)
    #Si es mayor o igual a 12 años: Solicitar alias
    if edad_jugador<=12:
      print("No tiene edad para jugar")
    else:
      alias_usuario = ""
      while len(alias_usuario)<=5 or alias_usuario.count(" ")!=0:
        #Pedir alias de usuario
        #alias_usuario = input("Alias:\n\t*No debe ser menor a 5 caractéres\n\t*No debe tener espacios")
        
        alias_usuario = "cuchiflí"
        
      #Si es mayor a 5 carácteres y sin espacios. Preguntar: ¿Eres nuevo?
      #jugador_nuevo = input("¿Eres nuevo jugando?: ")

      jugador_nuevo = "n"
      
      if jugador_nuevo == "s" or jugador_nuevo == "S" or jugador_nuevo == "si" or jugador_nuevo == "SI" or jugador_nuevo == "Si" or jugador_nuevo == "sI" or jugador_nuevo == "sizas" or jugador_nuevo == "Sizas":
        jugador_nuevo = True
      else:
        jugador_nuevo = False
        nivel_alcanzado = 0
        while not (nivel_alcanzado>=1 and nivel_alcanzado<=100):
          #Si ya ha jugado. Preguntar: ¿Hasta qué nivel llegaste?
          #nivel_alcanzado = int(input("¿Hasta qué nivel llegaste? [1-100] : "))
          
          nivel_alcanzado = 49

  mundo = mundo.ASIGNAR(edad_jugador, jugador_nuevo, nivel_alcanzado)
  print("Su CDIA es",CDIA,"y",CDIA_EXISTE)
  print("Su edad es",edad_jugador)
  print("Nuevo jugador",jugador_nuevo)
  print("Nivel alcanzado",nivel_alcanzado)
  print("Su nivel asignado es",mundo)

