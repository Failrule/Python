# Ayúdela a Yepeto  a cumplir con los requerimientos del reto  3
### documenté el código existente y el nuevo que incorporar al reto  
Cordial saludo apreciados beneficiarios en el reto ya se encuentran unas funciones desarrolladas las cuales te permitirán cumplir con el reto 3 del Modulo 3.    
La función CDIA_UNICO(CDIA) recibe un CDIA y validad  si ya se encuentra en lista, si lo encuentre retorna True( verdadero) de lo contrario False ( falso )
Antes de aplicar la función el CDIA debe estar validad  cumpliendo con las reglas establecidas 
 
## Reglas establecidas:  están programadas en los test de validación, se entrega una función con algunas   
 
CDIA es una cadena de 10 caracteres que debe cumplir con las siguientes restricciones y las cuales deben ser validadas por el programa una vez se ingresa: 
• Se debe verificar que el CDIA sea de tipo str exclusivamente y sin dígitos numéricos
 • En la posición 6 de la cadena del CDIA debe ir siempre el carácter arroba (‘@’) 
• El carácter en la primera posición y el carácter en la última posición del CDIA deben ser diferentes. 
• El CDIA debe contener en cualquier posición de la cadena el carácter  (‘+’)
 • El código CDIA no debe contener más de 3 veces la letra ’k
’ • El CDIA debe tener al menos uno de los siguientes símbolos (‘?’,’=’,’&’)
Si el CDIA no cumple con alguna de estas reglas se debe presentar el mensaje “CDIA inválido”

Función para retornar la edad con la fecha de nacimiento también encontraras la función age recibe una fecha de nacimiento y devuelve los años de la persona 
Revisa la documentación del reto 3 y completa las funciones restantes para ayudar a yepeto 